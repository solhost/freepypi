import tkinter as tk

# setup tk
root = tk.Tk()
root.title("chud program")
root.geometry("400x300")

# create elements

head = tk.Label(root, text="Chud Program", font=("Arial", 14))
head.pack()
explain = tk.Label(root, text="Chud Program is a simple Tk based application used to test freePyPI.")
explain.pack()
extras = tk.Label(root, text="If this popup worked, Your freePyPI toolchain most likely works.")
extras.pack()
def on_click():
    print("[Chud Program] Exit Chud Program and terminate Python and Tk.")
    exit()
done =  tk.Button(root, text="Close Chud Program", command=on_click)
done.pack()
root.mainloop()