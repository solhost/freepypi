import sys
import shutil
import os
import tomllib
from colorama import Fore, init

init(autoreset=True)

if len(sys.argv) == 1:
    print(Fore.LIGHTYELLOW_EX + "freePyPI" + Fore.WHITE + " wheel build utility")
elif len(sys.argv) > 1:
    if sys.argv[1] == "mk":
        if len(sys.argv) > 2:
            print(Fore.GREEN + "[- - -]" + Fore.WHITE + " Initialize wheel directory...")
            os.makedirs("wheel", exist_ok=True)
            shutil.copy(sys.argv[2], "wheel")
            shutil.copy("pyproject.toml", "wheel")
            print(Fore.CYAN + "[/]" + Fore.WHITE + " Completed initialization.")

            print(Fore.GREEN + "[- - -]" + Fore.WHITE + " Generate .whl file...")
            os.makedirs("dist", exist_ok=True)

            with open("pyproject.toml", "rb") as f:
                data = tomllib.load(f)
            package_name = data["name"]

            shutil.make_archive(f"dist/{package_name}", "zip", "wheel")
            os.rename(f"dist/{package_name}.zip", f"dist/{package_name}.whl")
            print(Fore.CYAN + "[/]" + Fore.WHITE + " Completed.")
        else:
            print(Fore.RED + "ERROR: Please provide a file as an argument.")
    else:
        print(Fore.RED + "ERROR: Please provide a subcommand as an argument.")