import sys
import time

class llstdout:
    def fprint(stdpr):
        print(stdpr, end="")
        sys.stdout.flush()
class config:
    def __init__(self):
        self.timeout = 0
    def set_timeout(self, time: int):
        self.timeout = time

cfg = config()


def main():
    # the length is always 10
    llstdout.fprint("[#         ]")
    time.sleep(cfg.timeout)
    llstdout.fprint("\r" + "[##        ]")
    # 8 to next 7 'n sn
    time.sleep(cfg.timeout)
    llstdout.fprint("\r" + "[###       ]")
    time.sleep(cfg.timeout)
    llstdout.fprint("\r" + "[####      ]")
    time.sleep(cfg.timeout)
    llstdout.fprint("\r" + "[#####     ]")
    time.sleep(cfg.timeout)
    llstdout.fprint("\r" + "[######    ]")
    time.sleep(cfg.timeout)
    llstdout.fprint("\r" + "[#######   ]")
    time.sleep(cfg.timeout)
    llstdout.fprint("\r" + "[########  ]")
    time.sleep(cfg.timeout)
    llstdout.fprint("\r" + "[######### ]")
    time.sleep(cfg.timeout)
    llstdout.fprint("\r" + "[##########]")